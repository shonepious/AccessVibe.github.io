import A_hand from "./Ahand.svg"
import B_hand from "./Bhand.svg"
import C_hand from "./Chand.svg"
import D_hand from "./Dhand.svg"
import E_hand from "./Ehand.svg"
import F_hand from "./Fhand.svg"
import G_hand from "./Ghand.svg"
import H_hand from "./Hhand.svg"
import I_hand from "./Ihand.svg"
import J_hand from "./Jhand.svg"
import K_hand from "./Khand.svg"
import L_hand from "./Lhand.svg"
import M_hand from "./Mhand.svg"
import N_hand from "./Nhand.svg"
import O_hand from "./Ohand.svg"
import P_hand from "./Phand.svg"
import Q_hand from "./Qhand.svg"
import R_hand from "./Rhand.svg"
import S_hand from "./Shand.svg"
import T_hand from "./Thand.svg"
import U_hand from "./Uhand.svg"
import V_hand from "./Vhand.svg"
import W_hand from "./Whand.svg"
import X_hand from "./Xhand.svg"
import Y_hand from "./Yhand.svg"
import Z_hand from "./Zhand.svg"

export const SignImage = [
  A_hand,
  B_hand,
  C_hand,
  D_hand,
  E_hand,
  F_hand,
  G_hand,
  H_hand,
  I_hand,
  J_hand,
  K_hand,
  L_hand,
  M_hand,
  N_hand,
  O_hand,
  P_hand,
  Q_hand,
  R_hand,
  S_hand,
  T_hand,
  U_hand,
  V_hand,
  W_hand,
  X_hand,
  Y_hand,
  Z_hand,
]
