import React, {useRef, useState} from 'react';
import * as tf from "@tensorflow/tfjs";
import * as handpose from "@tensorflow-models/handpose";
import SpeechRecognition, {useSpeechRecognition} from 'react-speech-recognition';
import Webcam from "react-webcam";
import { drawHand } from './utils';
import './App.css';
import * as fp from "fingerpose";
import { Handsigns } from './gestures';
import { SignImage } from './images';

const layout_style = {
  display: "grid",
  justifyItems: "center",
  alignItems: "center",
  width: "100vw",
}

const canvas_style = {
  gridColumn: 1,
  gridRow: 1,
  width: 1000,
  height: 600,
}

const textarea_style = {
  gridColumn: 1,
  gridRow: 2,
  width: 800,
  height: 95,
}

const button_style = {
  gridColumn: 3,
  gridRow: 2,
  width: 150,
  height: 100,
  marginLeft: 20
}

const table_style = {
  marginTop: 25,
  gap: 10,
  display: "grid",
  justifyItems: "center",
  alignItems: "center"
}

function App() {
  const webcamRef = useRef(null);
  const canvasRef = useRef(null);
  const textareaRef = useRef(null);
  let ellapsed = Date.now();
  let toggle = true;
  const {
    transcript,
    listening,
    resetTranscript,
    browserSupportsSpeechRecognition
  } = useSpeechRecognition();

  if (!browserSupportsSpeechRecognition) {
    alert("Browser doesn't support speech recognition.");
  }

  function DrawTable() {
    return SignImage.map((item, index) => (
      <img src={item} key={index} style={{gridColumn: index % 6 + 1}}/>
    ));
  }

  function speakText() {
    let utterance = new SpeechSynthesisUtterance();
    utterance.text = textareaRef.current.value;
    utterance.voice = window.speechSynthesis.getVoices()[0];
    window.speechSynthesis.speak(utterance);
  }

  const runHandpose = async () => {
    const net = await handpose.load();
    //  Loop and detect hands    
    setInterval(() => { detect(net);}, 100); 
  };

  const detect = async (net) => {
    // Check data is available
    if (
      typeof webcamRef.current !== "undefined" &&
      webcamRef.current !== null &&
      webcamRef.current.video.readyState === 4
    ) {
      // Get Video Properties
      const video = webcamRef.current.video;
      const videoWidth = webcamRef.current.video.videoWidth;
      const videoHeight = webcamRef.current.video.videoHeight;

      // Set video width
      webcamRef.current.video.width = videoWidth;
      webcamRef.current.video.height = videoHeight;

      // Set canvas height and width
      canvasRef.current.width = videoWidth;
      canvasRef.current.height = videoHeight;
      // Make Detections
      const hand = await net.estimateHands(video);

      if (hand.length > 0) {
        const GE = new fp.GestureEstimator([
          Handsigns.aSign,
          Handsigns.bSign,
          Handsigns.cSign,
          Handsigns.dSign,
          Handsigns.eSign,
          Handsigns.fSign,
          Handsigns.gSign,
          Handsigns.hSign,
          Handsigns.iSign,
          Handsigns.jSign,
          Handsigns.kSign,
          Handsigns.lSign,
          Handsigns.mSign,
          Handsigns.nSign,
          Handsigns.oSign,
          Handsigns.pSign,
          Handsigns.qSign,
          Handsigns.rSign,
          Handsigns.sSign,
          Handsigns.tSign,
          Handsigns.uSign,
          Handsigns.vSign,
          Handsigns.wSign,
          Handsigns.xSign,
          Handsigns.ySign,
          Handsigns.zSign,
        ]);

        const gesture = await GE.estimate(hand[0].landmarks, 8);
        if (gesture.gestures !== undefined && gesture.gestures.length > 0) {
          console.log(gesture.gestures);
          if (Date.now() - ellapsed >= 500) {
            ellapsed = Date.now();
            textareaRef.current.value = textareaRef.current.value + gesture.gestures[0].name;
          }
        }
      }

      const ctx = canvasRef.current.getContext("2d");
      drawHand(hand, ctx);
    }
  };

  
  runHandpose();

  return (
      <header className="App-header">
      <>
        <div style={layout_style}>
          <Webcam ref={webcamRef} style={canvas_style}/>
          <canvas ref={canvasRef} style={canvas_style} />
        </div>
        <div style={layout_style}>
          <textarea ref={textareaRef} id="text" style={textarea_style}></textarea>
          <button id="speak-button" onClick={speakText} style={button_style}>Speak</button>
        </div>
        <a href='./Speech-to-text.html'>Speech to text</a>

        <div style={table_style}>
          <DrawTable />
        </div>
        </>
      </header>
  );
}

export default App;

